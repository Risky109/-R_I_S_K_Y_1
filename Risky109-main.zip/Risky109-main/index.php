<?php
session_start();

// التأكد من تسجيل الدخول
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: login.php");
    exit();
}

// مجلد رفع الملفات
$uploadDir = "hex-mod/";
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

// قراءة الملفات الموجودة
$files = array_diff(scandir($uploadDir), array('.', '..'));
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>إدارة الملفات</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-dark text-white text-center">
    <div class="container mt-5">
        <h2>📁 إدارة الملفات</h2>
        
        <!-- زر تسجيل الخروج -->
        <a href="logout.php" class="btn btn-danger mb-3">🔓 تسجيل الخروج</a>

        <!-- فورم الرفع -->
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="MAX_FILE_SIZE" value="0"> <!-- يسمح برفع أي حجم -->
            <input type="file" name="file" class="form-control mb-3" required>
            <button type="submit" class="btn btn-success">رفع الملف</button>
        </form>

        <!-- قائمة الملفات -->
        <h3 class="mt-4">📂 الملفات المرفوعة</h3>
        <ul class="list-group">
            <?php if (!empty($files)): ?>
                <?php foreach ($files as $file): ?>
                    <li class="list-group-item bg-light text-dark d-flex justify-content-between align-items-center">
                        <a href="uploads/<?= urlencode($file) ?>" target="_blank"><?= htmlspecialchars($file) ?></a>
                        <a href="delete.php?file=<?= urlencode($file) ?>" class="btn btn-danger btn-sm">🗑 حذف</a>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="list-group-item bg-light text-dark">لا توجد ملفات مرفوعة بعد.</li>
            <?php endif; ?>
        </ul>
    </div>
</body>
</html>
