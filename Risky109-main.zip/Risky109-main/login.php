<?php
session_start();

// اكتب اسم حسابك اللي هتسجل بيه هنا
$valid_username = "admin";
$valid_password = "admin123";

// متحاولش تخطمطها علشان هيكس عمك اللي مسويها
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if ($username === $valid_username && $password === $valid_password) {
        $_SESSION["loggedin"] = true;
        header("Location: index.php");
        exit();
    } else {
        $error = "❌ اسم المستخدم أو كلمة المرور غير صحيحة!";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: url('hex-mod.png') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-box {
            background: rgba(0, 0, 0, 0.7);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.2);
            width: 50%;
        }
        .login-box h2 {
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: none;
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .btn-primary {
            width: 100%;
            background: #007bff;
            border: none;
            padding: 10px;
            font-size: 18px;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        .alert {
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h2>🔑 تسجيل الدخول</h2>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <form action="" method="post">
            <div class="mb-3">
                <input type="text" name="username" class="form-control" placeholder="اسم المستخدم" required>
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="كلمة المرور" required>
            </div>
            <button type="submit" class="btn btn-primary">تسجيل الدخول</button>
        </form>
    </div>

</body>
</html>
