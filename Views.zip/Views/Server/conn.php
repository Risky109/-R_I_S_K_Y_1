<?php

$servername = "ftpupload.net";
$dbname = "if0_38421876";
$username = "if0_38421876";
$password = "cDtFcfqMYa1w2LM";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>