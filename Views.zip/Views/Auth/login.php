<?= $this->extend('Layout/Starter') ?><?= $this->section('content') ?><style>
    @keyframes neonGlow {
        0% { color: #b0b0b0; text-shadow: 0 0 10px #b0b0b0; }
        50% { color: #ffffff; text-shadow: 0 0 15px #ffffff; }
        100% { color: #b0b0b0; text-shadow: 0 0 10px #b0b0b0; }
    }

    .pego-title {
        font-size: 2.5rem;
        font-weight: bold;
        animation: neonGlow 1.5s infinite alternate;
        text-align: center;
        margin-bottom: 20px;
    }


    #particles-js {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1; 
        background: #000; 
    }

    @keyframes glowingBox {
        0% { box-shadow: 0 0 15px #00ff99; }
        50% { box-shadow: 0 0 25px #00ff66; transform: scale(1.03); }
        100% { box-shadow: 0 0 15px #00ff99; }
    }

    .card {
        border-radius: 20px; 
        border: 3px solid #00ff99;
        animation: glowingBox 2s infinite alternate;
    }
</style><div id="particles-js"></div> <div class="d-flex flex-column min-vh-100 px-3 pt-4 fade-in">
    <div class="row justify-content-center my-auto">
        <div class="col-md-8 col-lg-6 col-xl-5">
            <div class="text-center mb-4">
                <a href="https://t.me/R_I_S_K_Y_1/">
                    <span class="pego-title">・ 𓆩 𓆩🇪🇬 R I S K Yᵛ͢ᵎᵖ𓆪𓆪</span>
                </a>
            </div><div class="card">
            <div class="card-body p-4">
                <div class="text-center mt-2">
                    <h5 class="text-primary">آلُِمآلُِڪ آلُِآسآسي </h5>
                    <p class="text-muted">@M_O_H_A_M_EDD</p>
                </div>
                <div class="p-2 mt-4">
                    <?= form_open() ?>

                    <div class="mb-3">
                        <label class="form-label" for="username">Username</label>
                        <input type="text" class="form-control glowing-input" name="username" id="username" placeholder="Your username" required minlength="4">
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="password">Password</label>
                        <input type="password" class="form-control glowing-input" name="password" id="password" placeholder="Your password" required minlength="6">
                    </div>

                    <div class="mt-3 text-end">
                        <button type="submit" class="btn glowing-btn w-100">
                            <i class="bi bi-box-arrow-in-right"></i> Log in
                        </button>
                    </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

</div><script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script><script>
    particlesJS("particles-js", {
        "particles": {
            "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
            "color": { "value": "#00ff99" },
            "shape": { "type": "circle" },
            "opacity": { "value": 0.5, "random": true },
            "size": { "value": 4, "random": true },
            "line_linked": { "enable": true, "distance": 150, "color": "#00ff99", "opacity": 0.4, "width": 1 },
            "move": { "enable": true, "speed": 2, "direction": "none" }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": { "onhover": { "enable": true, "mode": "repulse" }, "onclick": { "enable": true, "mode": "push" } },
            "modes": { "repulse": { "distance": 100, "duration": 0.4 } }
        },
        "retina_detect": true
    });
</script><?= $this->endSection() ?>