<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center pt-5 rounded-circle">
    <div class="col-lg-4">
        <?= $this->include('Layout/msgStatus') ?>
        <div class="card shadow-sm mb-5 rounded-circle">
            <div class="card-header h5 p-3 rounded-circle">
            </div>
                           </div>
            <div class="d-flex justify-content-center text-center mt-3 pt-1 rounded-circle">
                     <a class="nav-link text-warning text-center rounded-circle" href="https://t.me/R_I_S_K_Y_1/"><svg xmlns="http://www.w3.org/2000/svg" width="1.25em" height="1em" viewBox="0 0 640 512">
	<rect width="640" height="512" fill="none" />
	<path fill="currentColor" d="M14 325.3c2.3-4.2 5.2-4.9 9.7-2.5c10.4 5.6 20.6 11.4 31.2 16.7a595.88 595.88 0 0 0 127.4 46.3a616.61 616.61 0 0 0 63.2 11.8a603.33 603.33 0 0 0 95 5.2c17.4-.4 34.8-1.8 52.1-3.8a603.66 603.66 0 0 0 163.3-42.8c2.9-1.2 5.9-2 9.1-1.2c6.7 1.8 9 9 4.1 13.9a70 70 0 0 1-9.6 7.4c-30.7 21.1-64.2 36.4-99.6 47.9a473.31 473.31 0 0 1-75.1 17.6a431 431 0 0 1-53.2 4.8a21.3 21.3 0 0 0-2.5.3H308a21.3 21.3 0 0 0-2.5-.3c-3.6-.2-7.2-.3-10.7-.4a426.3 426.3 0 0 1-50.4-5.3A448.4 448.4 0 0 1 164 420a443.33 443.33 0 0 1-145.6-87c-1.8-1.6-3-3.8-4.4-5.7zM172 65.1l-4.3.6a80.92 80.92 0 0 0-38 15.1c-2.4 1.7-4.6 3.5-7.1 5.4a4.29 4.29 0 0 1-.4-1.4c-.4-2.7-.8-5.5-1.3-8.2c-.7-4.6-3-6.6-7.6-6.6h-11.5c-6.9 0-8.2 1.3-8.2 8.2v209.3c0 1 0 2 .1 3c.2 3 2 4.9 4.9 5c7 .1 14.1.1 21.1 0c2.9 0 4.7-2 5-5c.1-1 .1-2 .1-3v-72.4c1.1.9 1.7 1.4 2.2 1.9c17.9 14.9 38.5 19.8 61 15.4c20.4-4 34.6-16.5 43.8-34.9c7-13.9 9.9-28.7 10.3-44.1c.5-17.1-1.2-33.9-8.1-49.8c-8.5-19.6-22.6-32.5-43.9-36.9c-3.2-.7-6.5-1-9.8-1.5c-2.8-.1-5.5-.1-8.3-.1M124.6 107a3.48 3.48 0 0 1 1.7-3.3c13.7-9.5 28.8-14.5 45.6-13.2c14.9 1.1 27.1 8.4 33.5 25.9c3.9 10.7 4.9 21.8 4.9 33c0 10.4-.8 20.6-4 30.6c-6.8 21.3-22.4 29.4-42.6 28.5c-14-.6-26.2-6-37.4-13.9a3.57 3.57 0 0 1-1.7-3.3c.1-14.1 0-28.1 0-42.2s.1-28 0-42.1m205.7-41.9c-1 .1-2 .3-2.9.4a148 148 0 0 0-28.9 4.1c-6.1 1.6-12 3.8-17.9 5.8c-3.6 1.2-5.4 3.8-5.3 7.7c.1 3.3-.1 6.6 0 9.9c.1 4.8 2.1 6.1 6.8 4.9c7.8-2 15.6-4.2 23.5-5.7c12.3-2.3 24.7-3.3 37.2-1.4c6.5 1 12.6 2.9 16.8 8.4c3.7 4.8 5.1 10.5 5.3 16.4c.3 8.3.2 16.6.3 24.9a7.84 7.84 0 0 1-.2 1.4c-.5-.1-.9 0-1.3-.1a180.56 180.56 0 0 0-32-4.9c-11.3-.6-22.5.1-33.3 3.9c-12.9 4.5-23.3 12.3-29.4 24.9c-4.7 9.8-5.4 20.2-3.9 30.7c2 14 9 24.8 21.4 31.7c11.9 6.6 24.8 7.4 37.9 5.4c15.1-2.3 28.5-8.7 40.3-18.4a7.36 7.36 0 0 1 1.6-1.1c.6 3.8 1.1 7.4 1.8 11c.6 3.1 2.5 5.1 5.4 5.2c5.4.1 10.9.1 16.3 0a4.84 4.84 0 0 0 4.8-4.7a26.2 26.2 0 0 0 .1-2.8v-106a80 80 0 0 0-.9-12.9c-1.9-12.9-7.4-23.5-19-30.4c-6.7-4-14.1-6-21.8-7.1c-3.6-.5-7.2-.8-10.8-1.3c-3.9.1-7.9.1-11.9.1m35 127.7a3.33 3.33 0 0 1-1.5 3c-11.2 8.1-23.5 13.5-37.4 14.9c-5.7.6-11.4.4-16.8-1.8a20.08 20.08 0 0 1-12.4-13.3a32.9 32.9 0 0 1-.1-19.4c2.5-8.3 8.4-13 16.4-15.6a61.33 61.33 0 0 1 24.8-2.2c8.4.7 16.6 2.3 25 3.4c1.6.2 2.1 1 2.1 2.6c-.1 4.8 0 9.5 0 14.3s-.2 9.4-.1 14.1m259.9 129.4c-1-5-4.8-6.9-9.1-8.3a88.42 88.42 0 0 0-21-3.9a147.32 147.32 0 0 0-39.2 1.9c-14.3 2.7-27.9 7.3-40 15.6a13.75 13.75 0 0 0-3.7 3.5a5.11 5.11 0 0 0-.5 4c.4 1.5 2.1 1.9 3.6 1.8a16.2 16.2 0 0 0 2.2-.1c7.8-.8 15.5-1.7 23.3-2.5c11.4-1.1 22.9-1.8 34.3-.9a71.64 71.64 0 0 1 14.4 2.7c5.1 1.4 7.4 5.2 7.6 10.4c.4 8-1.4 15.7-3.5 23.3c-4.1 15.4-10 30.3-15.8 45.1a17.6 17.6 0 0 0-1 3c-.5 2.9 1.2 4.8 4.1 4.1a10.56 10.56 0 0 0 4.8-2.5a145.91 145.91 0 0 0 12.7-13.4c12.8-16.4 20.3-35.3 24.7-55.6c.8-3.6 1.4-7.3 2.1-10.9zM493.1 199q-19.35-53.55-38.7-107.2c-2-5.7-4.2-11.3-6.3-16.9c-1.1-2.9-3.2-4.8-6.4-4.8c-7.6-.1-15.2-.2-22.9-.1c-2.5 0-3.7 2-3.2 4.5a43.1 43.1 0 0 0 1.9 6.1q29.4 72.75 59.1 145.5c1.7 4.1 2.1 7.6.2 11.8c-3.3 7.3-5.9 15-9.3 22.3c-3 6.5-8 11.4-15.2 13.3a42.13 42.13 0 0 1-15.4 1.1c-2.5-.2-5-.8-7.5-1c-3.4-.2-5.1 1.3-5.2 4.8q-.15 5 0 9.9c.1 5.5 2 8 7.4 8.9a108.18 108.18 0 0 0 16.9 2c17.1.4 30.7-6.5 39.5-21.4a131.63 131.63 0 0 0 9.2-18.4q35.55-89.7 70.6-179.6a26.62 26.62 0 0 0 1.6-5.5c.4-2.8-.9-4.4-3.7-4.4c-6.6-.1-13.3 0-19.9 0a7.54 7.54 0 0 0-7.7 5.2c-.5 1.4-1.1 2.7-1.6 4.1l-34.8 100c-2.5 7.2-5.1 14.5-7.7 22.2c-.4-1.1-.6-1.7-.9-2.4" />
</svg> Now </a>
            </small>
        </p>
                 <small>
                        <a class="nav-link text-warning text-center rounded-circle" href="/register"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 64 64">
	<rect width="64" height="64" fill="none" />
	<path fill="#ff0000" d="M30.694 32.174c-1.168 1.088-10.529 10.17-10.529 10.17l2.499 2.464s8.317-7.676 9.566-8.837c.309-.286.832-.831 1.799-.831h28.365v-3.928H33.043c-.858.001-1.671.337-2.349.961zm16.805-21.351c3.326 0 5.141-2.303 5.141-5.141a5.14 5.14 0 1 0-5.141 5.141m-7.622 8.834h1.724l-2.526 9.075h16.85l-2.528-9.075h1.724l2.622 9.075h4.454l-3.58-12.042c-.473-1.663-2.576-4.609-6.217-4.609h-9.802c-3.639 0-5.74 2.946-6.217 4.609l-3.575 12.042h4.454zm-14.574 8.599l-4.525-8.437s-.266-.402-.759-.163c-.443.214-.243.713-.243.713l1.501 2.865l.934 1.785l-1.077-.485c-1.908-.86-2.96-1.227-3.382-1.416c-.075-.035-.445-.238-.621-.625c-.5-1.118-2.635-6.522-3.114-7.717c-.405-1.011-1.404-2.447-3.457-2.955c-2.337-.578-4.693.896-5.249 3.241L2.122 28.503c-.284 1.084-.772 4.016-.772 5.252l.021 26.254C1.387 62.224 2.986 64.01 5.199 64c2.21-.007 3.723-1.808 3.716-4.02L8.91 37.738l3.401-14.355c.397.971.889 2.154 1.05 2.438c.383.67.761 1.131 1.533 1.494c0 0 4.451 1.842 6.174 2.628a2.466 2.466 0 0 0 2.821-.782l.238-.493l.082.157s.507.893 1.256.934c.215-.681-.161-1.503-.161-1.503zm-6.88-22.618a5.141 5.141 0 1 1-10.283 0a5.142 5.142 0 0 1 10.283 0" />
	<path fill="#ff0000" d="m20.739 39.187l10.018-9.324l-1.302-1.397l-10.018 9.325z" />
</svg> Register </a>
            </small>
        </p>
            <small>
             <a class="nav-link text-warning text-center rounded-circle" href="/connect"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 48 48">
	<rect width="48" height="48" fill="none" />
	<path fill="none" stroke="#00ffff" stroke-linecap="round" stroke-linejoin="round" d="m19.463 23.268l-5.916-5.916M4.5 14.52v8.747l14.446-9.446a2.071 2.071 0 0 1 1.135-.339h2.882c.573 0 1.037.465 1.037 1.038v7.71c0 .573.465 1.037 1.037 1.037h2.882c.403 0 .798-.118 1.135-.338L43.5 13.482v8.748m-2.226 12.287v-6.72m-2.226 0H43.5m-26.997 6.72v-6.72l4.453 6.72v-6.72M8.952 32.263v.028c0 1.23-.996 2.226-2.226 2.226h0A2.226 2.226 0 0 1 4.5 32.291v-2.268c0-1.23.997-2.227 2.226-2.227h0c1.23 0 2.226.997 2.226 2.227v.027m23.018 4.467h-3.36v-6.72h3.36m-3.36 3.36h2.19m-18.117-3.36c1.23 0 2.226.997 2.226 2.226v2.268c0 1.23-.997 2.227-2.226 2.227h0a2.226 2.226 0 0 1-2.227-2.227v-2.268c0-1.23.997-2.226 2.227-2.226m9.876 6.72v-6.72l4.452 6.72v-6.72m10.724 4.466v.028c0 1.23-.996 2.226-2.226 2.226h0a2.226 2.226 0 0 1-2.226-2.226v-2.268c0-1.23.996-2.227 2.226-2.227h0c1.23 0 2.226.997 2.226 2.227v.027" />
</svg> Connect </a>
            </small>
        </p>  
    </div>
            <div class="card-body">
                <?= form_open() ?>
                <div class="form-group mb-2 rounded-circle">
                    <br/>
                    <br/>
                    <input type="text" class="text-info form-control mt-1 rounded-pill" name="username" id="username" aria-describedby="help-username" placeholder="Your username" required minlength="4">
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger rounded-circle"><?= $validation->getError('username') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-2">
                   
                    <input type="password" class="text-warning form-control mt-1 rounded-pill" name="password" id="password" aria-describedby="help-password" placeholder="Your password" required minlength="6">
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-danger"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                
                <!---->
                
                 <div class="form-group mb-3">
                    <input type="hidden" class="form-control mt-2 rounded-pill" name="ip" value="<?php echo $_SERVER['HTTP_USER_AGENT']; ?>" id="ip" aria-describedby="help-ip" required>
                    
                    <?php if ($validation->hasError('ip')) : ?>
                        <small id="help-password" class="form-text text-danger rounded-circle"><?= $validation->getError('ip') ?></small>
                    <?php endif; ?>
                </div>
                
                
                <!---->
                
                <div class="form-check mb-3">
                    <label class="form-check-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 30 minutes">
                        <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes">
                        Stay login?
                    </label>
                </div>
                <div class="form-group mb-2">
                    <button type="submit" class="btn btn-outline-warning rounded-circle"><i class="bi bi-box-arrow-in-right"></i> Log in</button>
                </div>
                <?= form_close() ?>
                </div>
      <div class="form-group mb-2 rounded-circle">
                
            </div>
        </div>
        <p class="text-center text-danger after-card">
            <small class="px-auto p-2 rounded">
                  Buy Now :-
            <a href="https://t.me/R_I_S_K_Y_1/" class="text-danger">@Yashu_MODS</a>
            </small>
            </p>
            </small>
        </p>
    </div>
</div>

<?= $this->endSection() ?>