<?php
$uploadDir = "uploads/";

if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["file"])) {
    $file = $_FILES["file"];
    $fileName = basename($file["name"]);
    $targetFilePath = $uploadDir . $fileName;

    if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {
        echo "<script>alert('تم رفع الملف بنجاح!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('حدث خطأ أثناء رفع الملف!'); window.location.href='index.php';</script>";
    }
}
?>
