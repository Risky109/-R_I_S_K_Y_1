<?php
session_start();

// التأكد من تسجيل الدخول
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: login.php");
    exit();
}

// التأكد من وجود اسم الملف
if (isset($_GET["file"])) {
    $file = "uploads/" . $_GET["file"];

    if (file_exists($file)) {
        unlink($file);
        echo "<script>alert('🗑 تم حذف الملف بنجاح!'); window.location.href='index.php';</script>";
    } else {
        echo "<script>alert('❌ الملف غير موجود!'); window.location.href='index.php';</script>";
    }
} else {
    header("Location: index.php");
}
?>
